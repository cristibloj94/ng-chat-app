export class Room {
    constructor(
        public roomName: string
    ) { }
}