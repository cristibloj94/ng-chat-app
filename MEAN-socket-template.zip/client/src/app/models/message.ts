export class Message {
  constructor(
    public author: string,
    public body: string,
    public roomName: string
  ) { }
}
