export class Blog {
  constructor(
    public author: string,
    public body: string
  ) {  }
}
